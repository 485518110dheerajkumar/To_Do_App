const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');



app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname,'public')));


app.set('view engine', 'ejs');



app.get("/",(req, res) =>{
    fs.readdir(`./files`,(error,files) =>{
        res.render("index",{files:files});
    })
    
})



app.post("/create",(req,res) =>{
    fs.writeFile(`./files/${req.body.tittle.split(' ').join('')}.txt`,req.body.discription,(error) =>{
        res.redirect("/");
    })
})



app.get("/info/:filename",(req, res) =>{
    fs.readFile(`./files/${req.params.filename}`,"utf-8",(error,response) =>{
        res.render("info",{filename:req.params.filename, filedata: response});
    })
    
})

app.get("/edit/:filename",(req, res) =>{
    res.render("edit",{filename:req.params.filename});
    
    
})

app.post("/edit",(req, res) =>{
    
    fs.rename(`./files/${req.body.prevtittle}`,`./files/${req.body.newtittle}`,(error)=>{
        res.redirect("/");
    });
})

app.get("/delete/:filename",(req, res) =>{
    res.render("delete",{file:req.params.filename});
    
})

app.post("/delete",(req, res) =>{
    fs.unlink(`./files/${req.body.filename}`,(error)=>{
        res.redirect("/");
        console.error(error);
    })
    
})


app.listen(3000,()=>{
    console.log("server is running in 3000 port");
})